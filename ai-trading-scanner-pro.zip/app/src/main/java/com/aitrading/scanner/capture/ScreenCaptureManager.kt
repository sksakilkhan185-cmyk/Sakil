package com.aitrading.scanner.capture

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlinx.coroutines.suspendCancellableCoroutine
import java.nio.ByteBuffer
import kotlin.coroutines.resume

object ScreenCaptureManager {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val handler = Handler(Looper.getMainLooper())

    var permissionResultCode: Int = 0
    var permissionData: Intent? = null

    fun isPermissionGranted(): Boolean {
        return permissionData != null && permissionResultCode != 0
    }

    fun initMediaProjection(context: Context) {
        if (mediaProjection != null) return
        val data = permissionData ?: return
        val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(permissionResultCode, data)
    }

    /**
     * Captures a single frame of the current screen.
     */
    @SuppressLint("WrongConstant")
    suspend fun captureScreen(context: Context): Bitmap? = suspendCancellableCoroutine { continuation ->
        try {
            if (mediaProjection == null) {
                initMediaProjection(context)
            }

            val projection = mediaProjection
            if (projection == null) {
                continuation.resume(null)
                return@suspendCancellableCoroutine
            }

            val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)

            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi

            // Setup ImageReader
            val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            imageReader = reader

            var isResumed = false

            reader.setOnImageAvailableListener({ ir ->
                if (isResumed) return@setOnImageAvailableListener
                var image: Image? = null
                try {
                    image = ir.acquireLatestImage()
                    if (image != null) {
                        isResumed = true
                        val planes = image.planes
                        val buffer: ByteBuffer = planes[0].buffer
                        val pixelStride = planes[0].pixelStride
                        val rowStride = planes[0].rowStride
                        val rowPadding = rowStride - pixelStride * width

                        // Create clean bitmap
                        val bitmap = Bitmap.createBitmap(
                            width + rowPadding / pixelStride,
                            height,
                            Bitmap.Config.ARGB_8888
                        )
                        bitmap.copyPixelsFromBuffer(buffer)

                        // Crop if rowPadding exists
                        val finalBitmap = if (rowPadding != 0) {
                            Bitmap.createBitmap(bitmap, 0, 0, width, height)
                        } else {
                            bitmap
                        }

                        cleanupVirtualDisplay()
                        continuation.resume(finalBitmap)
                    }
                } catch (e: Exception) {
                    cleanupVirtualDisplay()
                    if (!isResumed) {
                        isResumed = true
                        continuation.resume(null)
                    }
                } finally {
                    image?.close()
                }
            }, handler)

            virtualDisplay = projection.createVirtualDisplay(
                "TradingScreenCapture",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface,
                null,
                handler
            )

            // Timeout safety after 3 seconds
            handler.postDelayed({
                if (!isResumed) {
                    isResumed = true
                    cleanupVirtualDisplay()
                    continuation.resume(null)
                }
            }, 3000)

        } catch (e: Exception) {
            cleanupVirtualDisplay()
            continuation.resume(null)
        }
    }

    private fun cleanupVirtualDisplay() {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
            imageReader?.close()
            imageReader = null
        } catch (_: Exception) {
        }
    }

    fun release() {
        cleanupVirtualDisplay()
        try {
            mediaProjection?.stop()
            mediaProjection = null
        } catch (_: Exception) {
        }
    }
}
