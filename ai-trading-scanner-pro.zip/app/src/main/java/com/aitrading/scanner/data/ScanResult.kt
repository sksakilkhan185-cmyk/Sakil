package com.aitrading.scanner.data

import com.google.gson.annotations.SerializedName
import java.io.Serializable

enum class TradeDecision {
    @SerializedName("UP")
    UP,

    @SerializedName("DOWN")
    DOWN,

    @SerializedName("NO TRADE")
    NO_TRADE;

    companion object {
        fun fromString(value: String?): TradeDecision {
            return when (value?.uppercase()?.trim()) {
                "UP", "CALL", "BUY", "LONG" -> UP
                "DOWN", "PUT", "SELL", "SHORT" -> DOWN
                else -> NO_TRADE
            }
        }
    }
}

enum class TrendDirection {
    @SerializedName("BULLISH")
    BULLISH,

    @SerializedName("BEARISH")
    BEARISH,

    @SerializedName("SIDEWAYS")
    SIDEWAYS;

    companion object {
        fun fromString(value: String?): TrendDirection {
            return when (value?.uppercase()?.trim()) {
                "BULLISH", "UPTREND" -> BULLISH
                "BEARISH", "DOWNTREND" -> BEARISH
                else -> SIDEWAYS
            }
        }
    }
}

data class ScanAnalysisResult(
    @SerializedName("decision")
    val decision: TradeDecision = TradeDecision.NO_TRADE,

    @SerializedName("confidence")
    val confidence: Int = 0, // 0 - 100 percentage

    @SerializedName("historicalWinRate")
    val historicalWinRate: Double? = null, // Verified statistical win rate e.g. 74.5%

    @SerializedName("historicalSampleCount")
    val historicalSampleCount: Int? = null, // Number of verified historical trades

    @SerializedName("trend")
    val trend: TrendDirection = TrendDirection.SIDEWAYS,

    @SerializedName("timeframe")
    val timeframe: String = "15m",

    @SerializedName("candlestickPattern")
    val candlestickPattern: String? = null,

    @SerializedName("supportLevel")
    val supportLevel: String? = null,

    @SerializedName("resistanceLevel")
    val resistanceLevel: String? = null,

    @SerializedName("indicatorsVisible")
    val indicatorsVisible: List<String> = emptyList(),

    @SerializedName("explanation")
    val explanation: String = "",

    @SerializedName("keyRisks")
    val keyRisks: List<String> = emptyList(),

    @SerializedName("isChartLegible")
    val isChartLegible: Boolean = true,

    @SerializedName("scanTimestamp")
    val scanTimestamp: String = "",

    @SerializedName("id")
    val id: String = java.util.UUID.randomUUID().toString()
) : Serializable

data class UserTradeOutcome(
    val scanId: String,
    val patternName: String,
    val predictedDecision: TradeDecision,
    val actualOutcome: Boolean, // true = win, false = loss
    val timestamp: Long = System.currentTimeMillis()
)
