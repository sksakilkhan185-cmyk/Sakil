package com.aitrading.scanner

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aitrading.scanner.capture.ScreenCaptureManager
import com.aitrading.scanner.data.ScanAnalysisResult
import com.aitrading.scanner.data.ScanHistoryRepository
import com.aitrading.scanner.data.TradeDecision
import com.aitrading.scanner.data.UserTradeOutcome
import com.aitrading.scanner.network.GeminiApiClient
import com.aitrading.scanner.service.FloatingScannerService
import com.aitrading.scanner.ui.components.AnalysisPanel
import com.aitrading.scanner.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var repository: ScanHistoryRepository
    private val apiClient = GeminiApiClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = ScanHistoryRepository(this)

        setContent {
            AITradingScannerProTheme {
                MainScreen(
                    repository = repository,
                    apiClient = apiClient,
                    onStartFloatingService = { startFloatingService() },
                    onStopFloatingService = { stopFloatingService() }
                )
            }
        }
    }

    private fun startFloatingService() {
        val intent = Intent(this, FloatingScannerService::class.java).apply {
            action = FloatingScannerService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopFloatingService() {
        val intent = Intent(this, FloatingScannerService::class.java).apply {
            action = FloatingScannerService.ACTION_STOP
        }
        startService(intent)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    repository: ScanHistoryRepository,
    apiClient: GeminiApiClient,
    onStartFloatingService: () -> Unit,
    onStopFloatingService: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    // Overlay permission state
    var hasOverlayPermission by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var hasCapturePermission by remember { mutableStateOf(ScreenCaptureManager.isPermissionGranted()) }

    // Manual analysis state
    var isManualAnalyzing by remember { mutableStateOf(false) }
    var currentManualResult by remember { mutableStateOf<ScanAnalysisResult?>(null) }
    var selectedTimeframe by remember { mutableStateOf("15m") }

    // Win rate stats state
    var stats by remember { mutableStateOf(repository.getVerifiedWinRateStats()) }

    // Media projection launcher
    val projectionManager = remember {
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == ComponentActivity.RESULT_OK && result.data != null) {
            ScreenCaptureManager.permissionResultCode = result.resultCode
            ScreenCaptureManager.permissionData = result.data
            hasCapturePermission = true
            Toast.makeText(context, "Screen capture permission granted!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Screen capture permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    // Photo picker for manual screenshot testing
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                isManualAnalyzing = true
                try {
                    val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri))
                    } else {
                        @Suppress("DEPRECATION")
                        MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                    }

                    val analysis = apiClient.analyzeChart(bitmap, selectedTimeframe)
                    analysis.onSuccess { res ->
                        repository.saveScanResult(res)
                        stats = repository.getVerifiedWinRateStats()
                        currentManualResult = res
                    }.onFailure { err ->
                        Toast.makeText(context, "Analysis failed: ${err.message}", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "Image load error: ${e.message}", Toast.LENGTH_SHORT).show()
                } finally {
                    isManualAnalyzing = false
                }
            }
        }
    }

    Scaffold(
        containerColor = DarkBackground,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(PrimaryCyan)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "AI Trading Scanner Pro",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Permission Status Cards
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "SYSTEM PERMISSIONS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // 1. Overlay Permission
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Draw Over Other Apps", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("Required for movable floating button", fontSize = 11.sp, color = TextSecondary)
                        }
                        if (hasOverlayPermission) {
                            Badge(containerColor = AccentGreen) {
                                Text("GRANTED", modifier = Modifier.padding(4.dp), fontSize = 10.sp, color = Color.White)
                            }
                        } else {
                            Button(
                                onClick = {
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                    context.startActivity(intent)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Grant", fontSize = 12.sp, color = DarkBackground)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = BorderSubtle, thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    // 2. MediaProjection Screen Capture Consent
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Screen Capture Consent", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("Captures chart frame on scan tap", fontSize = 11.sp, color = TextSecondary)
                        }
                        if (hasCapturePermission) {
                            Badge(containerColor = AccentGreen) {
                                Text("READY", modifier = Modifier.padding(4.dp), fontSize = 10.sp, color = Color.White)
                            }
                        } else {
                            Button(
                                onClick = {
                                    mediaProjectionLauncher.launch(projectionManager.createScreenCaptureIntent())
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Allow", fontSize = 12.sp, color = DarkBackground)
                            }
                        }
                    }
                }
            }

            // Floating Scanner Controls
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(PrimaryCyan, Color(0xFF38BDF8))),
                    width = 1.dp
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "FLOATING SCANNER SERVICE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryCyan,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Spawns a draggable floating widget over TradingView, Binance, or broker apps for 1-tap AI chart reading.",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                if (!Settings.canDrawOverlays(context)) {
                                    Toast.makeText(context, "Grant overlay permission first", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (!ScreenCaptureManager.isPermissionGranted()) {
                                    mediaProjectionLauncher.launch(projectionManager.createScreenCaptureIntent())
                                    return@Button
                                }
                                onStartFloatingService()
                                Toast.makeText(context, "Floating scanner started!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = DarkBackground)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Start Scanner", color = DarkBackground, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                onStopFloatingService()
                                Toast.makeText(context, "Scanner stopped", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentRed)
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null, tint = AccentRed)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Stop", color = AccentRed, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Verified Historical Win Rate Tracker
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "VERIFIED ACCURACY TRACKER",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            val winRate = stats.first
                            if (winRate != null) {
                                Text(
                                    text = String.format("%.1f%%", winRate),
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black,
                                    color = AccentGreen
                                )
                            } else {
                                Text(
                                    text = "No trades verified yet",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextSecondary
                                )
                            }
                            Text(
                                text = "${stats.second} trades verified by you",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            tint = AccentGreen,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
            }

            // Manual Upload Option (Requirement 5: fallback when screen capture is unavailable)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "MANUAL SCREENSHOT UPLOAD",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Analyze any chart image from your gallery directly without overlay permissions.",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Timeframe Picker
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("1m", "5m", "15m", "1h", "4h", "1D").forEach { tf ->
                            FilterChip(
                                selected = selectedTimeframe == tf,
                                onClick = { selectedTimeframe = tf },
                                label = { Text(tf, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PrimaryCyan,
                                    selectedLabelColor = DarkBackground
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { photoPickerLauncher.launch("image/*") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryCyan),
                        enabled = !isManualAnalyzing
                    ) {
                        if (isManualAnalyzing) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = PrimaryCyan, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Scanning Chart with Gemini AI...", color = PrimaryCyan)
                        } else {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, tint = PrimaryCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Select Chart from Gallery", color = PrimaryCyan)
                        }
                    }
                }
            }

            // Show manual result panel if available
            currentManualResult?.let { result ->
                AnalysisPanel(
                    result = result,
                    onDismiss = { currentManualResult = null },
                    onRecordOutcome = { won ->
                        val outcome = UserTradeOutcome(
                            scanId = result.id,
                            patternName = result.candlestickPattern ?: "Chart Setup",
                            predictedDecision = result.decision,
                            actualOutcome = won
                        )
                        repository.recordOutcome(outcome)
                        stats = repository.getVerifiedWinRateStats()
                        Toast.makeText(context, "Trade verified and recorded!", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}
