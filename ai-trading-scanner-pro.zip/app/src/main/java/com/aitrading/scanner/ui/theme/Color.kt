package com.aitrading.scanner.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF131B2E)
val DarkCard = Color(0xFF1E293B)
val PrimaryCyan = Color(0xFF06B6D4)
val AccentGreen = Color(0xFF10B981)
val AccentRed = Color(0xFFEF4444)
val AccentAmber = Color(0xFFF59E0B)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val BorderSubtle = Color(0xFF334155)
