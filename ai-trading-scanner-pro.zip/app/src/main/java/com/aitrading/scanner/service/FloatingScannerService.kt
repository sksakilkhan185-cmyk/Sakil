package com.aitrading.scanner.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.aitrading.scanner.AnalysisDialogActivity
import com.aitrading.scanner.MainActivity
import com.aitrading.scanner.R
import com.aitrading.scanner.ScannerApplication
import com.aitrading.scanner.capture.ScreenCaptureManager
import com.aitrading.scanner.data.ScanHistoryRepository
import com.aitrading.scanner.network.GeminiApiClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class FloatingScannerService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null
    private lateinit var params: WindowManager.LayoutParams

    private lateinit var apiClient: GeminiApiClient
    private lateinit var repository: ScanHistoryRepository

    private var isScanning = false

    companion object {
        const val ACTION_START = "ACTION_START_FLOATING_SCANNER"
        const val ACTION_STOP = "ACTION_STOP_FLOATING_SCANNER"
        const val NOTIFICATION_ID = 1001
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        apiClient = GeminiApiClient()
        repository = ScanHistoryRepository(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForegroundNotification()
                if (floatingView == null) {
                    createFloatingWidget()
                }
            }
        }
        return START_STICKY
    }

    private fun startForegroundNotification() {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, FloatingScannerService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, ScannerApplication.CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Scanner", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                // Android 14+ requires mediaProjection foreground service type
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createFloatingWidget() {
        // Layout params for floating system overlay
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 300
        }

        // Programmatic cyber-styled floating badge
        val rootLayout = FrameLayout(this)
        val density = resources.displayMetrics.density
        val sizePx = (64 * density).toInt()

        val buttonContainer = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(sizePx, sizePx)
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                colors = intArrayOf(Color.parseColor("#06B6D4"), Color.parseColor("#0284C7"), Color.parseColor("#0F172A"))
                gradientType = GradientDrawable.RADIAL_GRADIENT
                gradientRadius = (sizePx / 1.5).toFloat()
                setStroke((2 * density).toInt(), Color.parseColor("#38BDF8"))
            }
            background = bg
            elevation = 16 * density
        }

        // Scanner Icon & Text
        val label = TextView(this).apply {
            text = "AI SCAN"
            setTextColor(Color.WHITE)
            textSize = 10f
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            val lp = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT)
            lp.gravity = Gravity.CENTER
            layoutParams = lp
        }

        // Loading spinner for scan in progress
        val progressBar = ProgressBar(this).apply {
            visibility = View.GONE
            val lp = FrameLayout.LayoutParams((36 * density).toInt(), (36 * density).toInt())
            lp.gravity = Gravity.CENTER
            layoutParams = lp
        }

        buttonContainer.addView(label)
        buttonContainer.addView(progressBar)
        rootLayout.addView(buttonContainer)

        // Gesture Drag & Click Handling
        rootLayout.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isClick = true

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isClick = true
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - initialTouchX
                        val dy = event.rawY - initialTouchY
                        if (abs(dx) > 10 || abs(dy) > 10) {
                            isClick = false
                        }
                        params.x = initialX + dx.toInt()
                        params.y = initialY + dy.toInt()
                        windowManager.updateViewLayout(rootLayout, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (isClick && !isScanning) {
                            triggerScan(buttonContainer, label, progressBar)
                        }
                        return true
                    }
                }
                return false
            }
        })

        floatingView = rootLayout
        windowManager.addView(rootLayout, params)
    }

    private fun triggerScan(container: View, label: TextView, progressBar: ProgressBar) {
        if (isScanning) return
        isScanning = true

        // Haptic feedback
        vibratePhone()

        // UI state: Scanning
        label.visibility = View.GONE
        progressBar.visibility = View.VISIBLE

        serviceScope.launch {
            try {
                // Check if screen capture consent was provided
                if (!ScreenCaptureManager.isPermissionGranted()) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@FloatingScannerService,
                            "MediaProjection consent required. Please open AI Scanner app.",
                            Toast.LENGTH_LONG
                        ).show()
                        resetScanButton(label, progressBar)
                    }
                    return@launch
                }

                // Briefly hide overlay button so it doesn't obstruct the chart screenshot!
                floatingView?.visibility = View.INVISIBLE
                kotlinx.coroutines.delay(120)

                // Capture current screen frame
                val bitmap = ScreenCaptureManager.captureScreen(this@FloatingScannerService)

                // Restore overlay visibility
                floatingView?.visibility = View.VISIBLE

                if (bitmap == null) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@FloatingScannerService, "Failed to capture screen", Toast.LENGTH_SHORT).show()
                        resetScanButton(label, progressBar)
                    }
                    return@launch
                }

                // Analyze chart via Gemini backend
                val result = apiClient.analyzeChart(bitmap, timeframe = "Auto")

                withContext(Dispatchers.Main) {
                    resetScanButton(label, progressBar)
                    result.onSuccess { analysis ->
                        // Save to verified history repository
                        repository.saveScanResult(analysis)

                        // Launch full Analysis Dialog Activity over the screen
                        val dialogIntent = Intent(this@FloatingScannerService, AnalysisDialogActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                            putExtra(AnalysisDialogActivity.EXTRA_SCAN_RESULT, analysis)
                        }
                        startActivity(dialogIntent)
                    }.onFailure { err ->
                        Toast.makeText(
                            this@FloatingScannerService,
                            "Scan error: ${err.localizedMessage}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    floatingView?.visibility = View.VISIBLE
                    resetScanButton(label, progressBar)
                    Toast.makeText(this@FloatingScannerService, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun resetScanButton(label: TextView, progressBar: ProgressBar) {
        isScanning = false
        progressBar.visibility = View.GONE
        label.visibility = View.VISIBLE
    }

    private fun vibratePhone() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(50)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        if (floatingView != null) {
            windowManager.removeView(floatingView)
            floatingView = null
        }
        ScreenCaptureManager.release()
    }
}
