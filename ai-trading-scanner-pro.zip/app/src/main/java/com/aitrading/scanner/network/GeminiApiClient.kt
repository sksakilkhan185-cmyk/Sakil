package com.aitrading.scanner.network

import android.graphics.Bitmap
import android.util.Base64
import com.aitrading.scanner.BuildConfig
import com.aitrading.scanner.data.ScanAnalysisResult
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class GeminiApiClient(private var baseUrl: String = BuildConfig.BACKEND_BASE_URL) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()

    fun updateBaseUrl(newUrl: String) {
        baseUrl = newUrl.trimEnd('/')
    }

    suspend fun analyzeChart(bitmap: Bitmap, timeframe: String): Result<ScanAnalysisResult> = withContext(Dispatchers.IO) {
        try {
            // Compress bitmap to JPEG base64 (scaled down to max 1280px to save bandwidth while preserving candlestick sharpness)
            val scaledBitmap = scaleBitmapToMaxDimension(bitmap, 1280)
            val outputStream = ByteArrayOutputStream()
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
            val byteArray = outputStream.toByteArray()
            val base64Image = Base64.encodeToString(byteArray, Base64.NO_WRAP)

            val jsonBody = JSONObject().apply {
                put("image", "data:image/jpeg;base64,$base64Image")
                put("timeframe", timeframe)
            }

            val requestBody = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val url = "$baseUrl/api/analyze-chart"

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .header("User-Agent", "AITradingScannerPro-Android/1.0")
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()

            if (!response.isSuccessful || responseBody.isNullOrEmpty()) {
                return@withContext Result.failure(
                    Exception("Server error [${response.code}]: ${responseBody ?: "Empty response"}")
                )
            }

            val result = gson.fromJson(responseBody, ScanAnalysisResult::class.java)
            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun scaleBitmapToMaxDimension(source: Bitmap, maxDim: Int): Bitmap {
        val width = source.width
        val height = source.height
        if (width <= maxDim && height <= maxDim) return source

        val ratio = width.toFloat() / height.toFloat()
        val newWidth: Int
        val newHeight: Int
        if (width > height) {
            newWidth = maxDim
            newHeight = (maxDim / ratio).toInt()
        } else {
            newHeight = maxDim
            newWidth = (maxDim * ratio).toInt()
        }
        return Bitmap.createScaledBitmap(source, newWidth, newHeight, true)
    }
}
