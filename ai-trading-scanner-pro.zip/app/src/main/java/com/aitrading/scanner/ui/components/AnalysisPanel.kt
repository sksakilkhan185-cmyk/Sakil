package com.aitrading.scanner.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aitrading.scanner.data.ScanAnalysisResult
import com.aitrading.scanner.data.TradeDecision
import com.aitrading.scanner.data.TrendDirection

@Composable
fun AnalysisPanel(
    result: ScanAnalysisResult,
    onDismiss: () -> Unit,
    onRecordOutcome: ((Boolean) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    // Decision styling
    val decisionColor = when (result.decision) {
        TradeDecision.UP -> Color(0xFF10B981) // Neon Green
        TradeDecision.DOWN -> Color(0xFFEF4444) // Bright Red
        TradeDecision.NO_TRADE -> Color(0xFFF59E0B) // Amber
    }

    val decisionIcon: ImageVector = when (result.decision) {
        TradeDecision.UP -> Icons.Default.TrendingUp
        TradeDecision.DOWN -> Icons.Default.TrendingDown
        TradeDecision.NO_TRADE -> Icons.Default.Block
    }

    val decisionText = when (result.decision) {
        TradeDecision.UP -> "UP / CALL"
        TradeDecision.DOWN -> "DOWN / PUT"
        TradeDecision.NO_TRADE -> "NO TRADE"
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF0F172A)
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.verticalGradient(
                colors = listOf(decisionColor.copy(alpha = 0.8f), Color(0xFF1E293B))
            ),
            width = 1.5.dp
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .verticalScroll(scrollState)
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF06B6D4))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AI VISION ANALYSIS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF94A3B8),
                        letterSpacing = 1.5.sp
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color(0xFF94A3B8)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Primary Decision HUD Badge
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(decisionColor.copy(alpha = 0.12f))
                    .border(1.dp, decisionColor.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                    .padding(vertical = 16.dp, horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = decisionIcon,
                        contentDescription = null,
                        tint = decisionColor,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = decisionText,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Black,
                            color = decisionColor,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = if (result.decision == TradeDecision.NO_TRADE)
                                "Signal inconclusive or high-risk market state"
                            else
                                "High-probability directional setup detected",
                            fontSize = 11.sp,
                            color = Color(0xFFCBD5E1)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Dual Metrics: Estimated Confidence vs Verified Historical Win Rate
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Estimated Confidence
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFF1E293B)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "ESTIMATED CONFIDENCE",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF94A3B8)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "${result.confidence}",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "%",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF06B6D4),
                                modifier = Modifier.padding(bottom = 2.dp, start = 2.dp)
                            )
                        }
                        Text(
                            text = "Pattern vision strength",
                            fontSize = 9.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                // Verified Historical Win Rate
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFF1E293B)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "HISTORICAL WIN RATE",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF94A3B8)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            if (result.historicalWinRate != null) {
                                Text(
                                    text = String.format("%.1f", result.historicalWinRate),
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF10B981)
                                )
                                Text(
                                    text = "%",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF10B981),
                                    modifier = Modifier.padding(bottom = 2.dp, start = 2.dp)
                                )
                            } else {
                                Text(
                                    text = "N/A",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }
                        Text(
                            text = if (result.historicalSampleCount != null && result.historicalSampleCount > 0)
                                "${result.historicalSampleCount} verified trades"
                            else
                                "No verified trades yet",
                            fontSize = 9.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Key Market Facts Row (Trend, Timeframe, Candlestick)
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF1E293B)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Trend & Timeframe
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("TREND DIRECTION", fontSize = 9.sp, color = Color(0xFF94A3B8))
                            Text(
                                text = result.trend.name,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (result.trend) {
                                    TrendDirection.BULLISH -> Color(0xFF10B981)
                                    TrendDirection.BEARISH -> Color(0xFFEF4444)
                                    TrendDirection.SIDEWAYS -> Color(0xFFE2E8F0)
                                }
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("TIMEFRAME", fontSize = 9.sp, color = Color(0xFF94A3B8))
                            Text(
                                text = result.timeframe,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8)
                            )
                        }
                    }

                    if (!result.candlestickPattern.isNullOrEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = Color(0xFF334155), thickness = 0.5.dp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("DETECTED PATTERN", fontSize = 9.sp, color = Color(0xFF94A3B8))
                        Text(
                            text = result.candlestickPattern,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFF8FAFC)
                        )
                    }

                    // S/R Levels
                    if (!result.supportLevel.isNullOrEmpty() || !result.resistanceLevel.isNullOrEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            if (!result.supportLevel.isNullOrEmpty()) {
                                Column {
                                    Text("SUPPORT", fontSize = 9.sp, color = Color(0xFF10B981))
                                    Text(result.supportLevel, fontSize = 12.sp, color = Color.White)
                                }
                            }
                            if (!result.resistanceLevel.isNullOrEmpty()) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("RESISTANCE", fontSize = 9.sp, color = Color(0xFFEF4444))
                                    Text(result.resistanceLevel, fontSize = 12.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }

            // Visible Indicators Chip Row
            if (result.indicatorsVisible.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "IDENTIFIED INDICATORS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    result.indicatorsVisible.forEach { indicator ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF1E293B).copy(alpha = 0.8f)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF06B6D4),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = indicator,
                                    fontSize = 11.sp,
                                    color = Color(0xFFCBD5E1)
                                )
                            }
                        }
                    }
                }
            }

            // Technical Explanation
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "TECHNICAL EXPLANATION",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF94A3B8)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF131B2E)
            ) {
                Text(
                    text = result.explanation.ifEmpty { "Price action analysis complete." },
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    color = Color(0xFFE2E8F0),
                    modifier = Modifier.padding(12.dp)
                )
            }

            // Timestamp Footer
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Scan: ${result.scanTimestamp.ifEmpty { "Just now" }}",
                    fontSize = 9.sp,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = "Non-hallucinatory strict verification",
                    fontSize = 9.sp,
                    color = Color(0xFF64748B)
                )
            }

            // Log Outcome Action Buttons (for training historical win rate accurately)
            if (onRecordOutcome != null && result.decision != TradeDecision.NO_TRADE) {
                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = Color(0xFF334155), thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "VERIFY THIS TRADE OUTCOME:",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onRecordOutcome(true) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("WON (Target Hit)", fontSize = 11.sp, color = Color.White)
                    }

                    Button(
                        onClick = { onRecordOutcome(false) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("LOST (Stop Hit)", fontSize = 11.sp, color = Color.White)
                    }
                }
            }
        }
    }
}
