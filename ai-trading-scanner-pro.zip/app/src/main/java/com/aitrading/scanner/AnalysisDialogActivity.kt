package com.aitrading.scanner

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.aitrading.scanner.data.ScanAnalysisResult
import com.aitrading.scanner.data.ScanHistoryRepository
import com.aitrading.scanner.data.UserTradeOutcome
import com.aitrading.scanner.ui.components.AnalysisPanel
import com.aitrading.scanner.ui.theme.AITradingScannerProTheme

class AnalysisDialogActivity : ComponentActivity() {

    companion object {
        const val EXTRA_SCAN_RESULT = "extra_scan_result"
    }

    private lateinit var repository: ScanHistoryRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repository = ScanHistoryRepository(this)

        @Suppress("DEPRECATION")
        val scanResult = intent.getSerializableExtra(EXTRA_SCAN_RESULT) as? ScanAnalysisResult
            ?: ScanAnalysisResult()

        setContent {
            AITradingScannerProTheme {
                // Dimmed background that dismisses on outside tap
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.65f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            finish()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    AnalysisPanel(
                        result = scanResult,
                        onDismiss = { finish() },
                        onRecordOutcome = { won ->
                            val outcome = UserTradeOutcome(
                                scanId = scanResult.id,
                                patternName = scanResult.candlestickPattern ?: "Generic Setup",
                                predictedDecision = scanResult.decision,
                                actualOutcome = won
                            )
                            repository.recordOutcome(outcome)
                            Toast.makeText(
                                this@AnalysisDialogActivity,
                                "Verified trade recorded! Stats updated.",
                                Toast.LENGTH_SHORT
                            ).show()
                            finish()
                        }
                    )
                }
            }
        }
    }
}
