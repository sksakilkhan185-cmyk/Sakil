package com.aitrading.scanner.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ScanHistoryRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("scanner_history_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    companion object {
        private const val KEY_HISTORY = "scan_history_list"
        private const val KEY_VERIFIED_OUTCOMES = "verified_outcomes_list"
    }

    fun saveScanResult(result: ScanAnalysisResult) {
        val list = getScanHistory().toMutableList()
        list.add(0, result) // Add latest first
        if (list.size > 50) list.removeAt(list.size - 1)
        prefs.edit().putString(KEY_HISTORY, gson.toJson(list)).apply()
    }

    fun getScanHistory(): List<ScanAnalysisResult> {
        val json = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return try {
            val type = object : TypeToken<List<ScanAnalysisResult>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun recordOutcome(outcome: UserTradeOutcome) {
        val list = getVerifiedOutcomes().toMutableList()
        list.add(outcome)
        prefs.edit().putString(KEY_VERIFIED_OUTCOMES, gson.toJson(list)).apply()
    }

    fun getVerifiedOutcomes(): List<UserTradeOutcome> {
        val json = prefs.getString(KEY_VERIFIED_OUTCOMES, null) ?: return emptyList()
        return try {
            val type = object : TypeToken<List<UserTradeOutcome>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Calculates the true historical win rate from verified user trade records.
     * Never invents results.
     */
    fun getVerifiedWinRateStats(): Pair<Double?, Int> {
        val outcomes = getVerifiedOutcomes()
        if (outcomes.isEmpty()) {
            return Pair(null, 0)
        }
        val wins = outcomes.count { it.actualOutcome }
        val winRate = (wins.toDouble() / outcomes.size.toDouble()) * 100.0
        return Pair(winRate, outcomes.size)
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
