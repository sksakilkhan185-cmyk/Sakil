# Phone-Only Build & Compilation Guide: AI Trading Scanner Pro

This guide allows you to compile, build, and install the **AI Trading Scanner Pro** APK **directly from your Android phone without needing a computer or PC**.

---

## ⚡ Method 1: Cloud Build via GitHub Actions (Easiest & Fastest — 3 Minutes)

This method uses GitHub's free cloud runners. You can do everything right in Chrome or the GitHub mobile app on your Android phone.

### Step 1: Download the Project
1. In the web workbench, tap the **"Download Complete Android Project (.ZIP)"** button.
2. The file `ai-trading-scanner-pro.zip` will download to your phone's `Downloads` folder.

### Step 2: Push to GitHub from Phone
1. Open [github.com](https://github.com) on your phone browser (or GitHub app) and tap **New Repository** (name it `ai-trading-scanner-pro`).
2. Tap **Upload files**, unzip or upload the project files, and commit to `main`.
   *(Or if using Termux: `git init && git add . && git commit -m "initial" && git push`)*.

### Step 3: Automated APK Build & Download
1. Navigate to the **Actions** tab in your repository.
2. You will see the **"Build Android Debug APK"** workflow running automatically.
3. Once completed (~2 minutes), tap the workflow run and scroll down to **Artifacts**.
4. Tap **AI-Trading-Scanner-Pro-Debug-APK** to download `app-debug.apk` directly to your phone!
5. Tap the downloaded APK to install it.

---

## 📱 Method 2: Native On-Device Compilation using AndroidIDE

**AndroidIDE** is an open-source, full-featured Android development environment that runs natively on Android devices.

### Step 1: Install AndroidIDE on your phone
1. Download AndroidIDE from [F-Droid](https://f-droid.org/en/packages/com.itsaky.androidide/) or from [androidide.com](https://androidide.com).
2. Open AndroidIDE and follow the initial setup (it downloads the required Android SDK and JDK 17 automatically on your phone).

### Step 2: Open the Project
1. Extract `ai-trading-scanner-pro.zip` into your phone's internal storage (e.g. `/sdcard/AndroidIDEProjects/`).
2. In AndroidIDE, tap **Open Project** and select the folder.

### Step 3: Build & Install
1. Tap the **Build** hammer icon in the top toolbar.
2. AndroidIDE runs Gradle and compiles the debug APK.
3. Once built, AndroidIDE presents a 1-tap **Install** prompt directly on your device.

---

## 💻 Method 3: Direct Compilation on Phone using Termux

If you enjoy command-line control, you can build the APK directly inside **Termux** on your phone.

### Step 1: Install Termux & Dependencies
Open Termux and run:
```bash
pkg update && pkg upgrade -y
pkg install openjdk-17 gradle git wget unzip -y
```

### Step 2: Extract & Build
```bash
# Navigate to your extracted project folder
cd ~/storage/downloads/ai-trading-scanner-pro/android

# Make gradlew executable
chmod +x gradlew

# Build the Debug APK
./gradlew assembleDebug
```

The APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

To install it directly:
```bash
termux-open app/build/outputs/apk/debug/app-debug.apk
```

---

## ⚙️ Android Permissions Setup on Your Phone

Once installed, launch **AI Trading Scanner Pro**:

1. **Draw Over Other Apps (Overlay Permission)**:
   - Tap **"Grant"** under System Permissions.
   - Android Settings will open -> toggle **"Allow display over other apps"** for AI Trading Scanner Pro.
   - Return to the app.

2. **Screen Capture Consent (MediaProjection)**:
   - Tap **"Allow"** under Screen Capture Consent.
   - Android will display the system prompt: *"AI Trading Scanner Pro will start capturing everything that's displayed on your screen"*.
   - Tap **"Start now"** (or "While using the app").

3. **Start the Scanner**:
   - Tap **"Start Scanner"**.
   - A circular neon cyan **"AI SCAN"** button will appear on your screen.
   - Open TradingView, Binance, MT5, or any chart application.
   - Drag the floating button to any comfortable spot.
   - Tap the button whenever you want an instant vision analysis of your chart!
