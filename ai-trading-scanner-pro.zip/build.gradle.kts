// Top-level build file for AI Trading Scanner Pro
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
}
